extends Area2D

signal enemy_died
@export var speed: float = 50
var hp: int = 1
@onready var hurt_sound: AudioStreamPlayer2D = $HurtSound

func _physics_process(delta: float) -> void:
	global_position.y += speed * delta

func take_damage(damage: int) -> void:
	hp -= damage
	if hp <= 0:
		emit_signal("enemy_died")  # ✅ This must trigger
		queue_free()

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("player"):
		area.take_damage(1)
		queue_free()
