extends Area2D

@export var speed: float = 600

func _physics_process(delta: float) -> void:
	global_position.y -= speed * delta
	if global_position.y < -100:
		queue_free()

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("enemies"):
		area.take_damage(1)
		queue_free()
