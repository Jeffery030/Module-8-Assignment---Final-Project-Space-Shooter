extends Area2D
class_name Player

signal spawn_laser(location: Vector2)
signal player_died

@export var speed: float = 300
@onready var muzzle: Node2D = $Muzzle
@onready var hurt_sound: AudioStreamPlayer2D = $HurtSound
var hp := 3
var input_vector := Vector2.ZERO

func _physics_process(delta: float) -> void:
	input_vector.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
	input_vector.y = Input.get_action_strength("move_down") - Input.get_action_strength("move_up")
	input_vector = input_vector.normalized()
	global_position += input_vector * speed * delta
	if Input.is_action_just_pressed("shoot"):
		shoot_laser()

func shoot_laser() -> void:
	emit_signal("spawn_laser", muzzle.global_position)

func take_damage(damage: int) -> void:
	hp -= damage
	hurt_sound.play()
	if has_node("/root/World/CanvasLayer"):
		var hud = get_node("/root/World/CanvasLayer")
		hud.flash_life(hp)   # make the lost heart flash
	if hp <= 0:
		emit_signal("player_died")
		queue_free()


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("enemies"):
		area.take_damage(1)   # enemy takes damage
		take_damage(1)        # ✅ this works, because Player has take_damage()
