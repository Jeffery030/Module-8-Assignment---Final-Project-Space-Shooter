extends CanvasLayer

@onready var message: Label = $Label             # your message label
@onready var score_label: Label = $ScoreLabel
@onready var lives_counter := $HBoxContainer.get_children()
@onready var timer: Timer = $Timer


func show_message(text: String) -> void:
	message.text = text
	message.show()
	timer.start()

func _on_Timer_timeout() -> void:
	message.hide()

func _on_timer_timeout() -> void:
	pass # Replace with function body.
	
func update_score(value: int) -> void:
	score_label.text = str(value)

func update_lives(value: int) -> void:
	for i in range(3):
		lives_counter[i].visible = value > i
	
func flash_life(life_index: int) -> void:
	if life_index >= 0 and life_index < lives_counter.size():
		var heart = lives_counter[life_index]
		var tween := create_tween()
		tween.tween_property(heart, "modulate", Color(1, 0.2, 0.2), 0.1)  # flash red
		tween.tween_property(heart, "modulate", Color(1, 1, 1), 0.2)     # back to normal
