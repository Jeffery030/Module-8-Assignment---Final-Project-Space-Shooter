extends Node2D

var spawn_positions: Array
const EnemyScene := preload("res://enemy.tscn")
var enemies: Array = []

func _ready() -> void:
	randomize()
	spawn_positions = $SpawnPositions.get_children()
	$SpawnTimer.start()

func spawn_enemy():
	if spawn_positions.is_empty():
		push_warning("No spawn positions found!")
		return

	var idx := randi() % spawn_positions.size()
	var e := EnemyScene.instantiate()
	e.global_position = spawn_positions[idx].global_position
	add_child(e)

	# ✅ Connect enemy signal to world
	e.connect("enemy_died", Callable(self, "_on_enemy_died"))

	print("Spawned enemy at:", e.global_position)

func _on_spawn_timer_timeout() -> void:
	spawn_enemy()

func kill_last_enemy() -> void:
	if enemies.size() > 0:
		enemies.back().queue_free()
		enemies.pop_back()
		print("Spawn positions:", spawn_positions.size())
