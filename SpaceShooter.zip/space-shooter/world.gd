extends Node2D

@onready var player = $Player
@onready var game_over_panel: Control = $CanvasLayer/GameOverPanel
@onready var hud = $CanvasLayer

@export var LaserScene: PackedScene = preload("res://player_laser.tscn")

var score_value: int = 0

func _ready() -> void:
	if not player.is_connected("spawn_laser", Callable(self, "_on_player_spawn_laser")):
		player.connect("spawn_laser", Callable(self, "_on_player_spawn_laser"))
	if not player.is_connected("player_died", Callable(self, "_on_player_died")):
		player.connect("player_died", Callable(self, "_on_player_died"))

func _on_player_spawn_laser(location: Vector2) -> void:
	var laser = LaserScene.instantiate()
	laser.global_position = location
	add_child(laser)

func _on_player_died() -> void:
	print("GAME OVER")
	hud.show_message("GAME OVER")   # ✅ show message
	game_over_panel.visible = true  # ✅ display panel
	get_tree().paused = true        # ✅ freeze game

func _on_enemy_died() -> void:
	score_value += 100
	print("Score:", score_value)  # test output
	hud.update_score(score_value)
